---
name: Bug Report
about: Báo cáo lỗi trong hệ thống
labels: bug
---

## Module bị lỗi

<!-- src/ingestion, src/retrieval, UI, ... -->

## Mô tả lỗi

<!-- Lỗi gì? Khi nào xảy ra? -->

## Steps to reproduce

1. ...
2. ...

## Expected vs Actual

- **Expected:** ...
- **Actual:** ...

## Log / Error message

```
paste log here
```
