---
name: Feature / Task
about: Task mới cho một phase
labels: ''
---

## Mô tả

<!-- Task này làm gì? -->

## Người phụ trách

- [ ] P1
- [ ] P2
- [ ] P3
- [ ] P4
- [ ] P5

## Phase

Phase: __

## Output cụ thể

<!-- File, function, hay artifact nào sẽ được tạo ra? -->

## Definition of Done

Xem [`docs/team/definition_of_done.md`](../../docs/team/definition_of_done.md)

- [ ] ...
