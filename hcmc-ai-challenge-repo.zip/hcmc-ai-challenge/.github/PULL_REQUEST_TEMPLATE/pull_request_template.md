## Mô tả

<!-- Tóm tắt ngắn những gì PR này làm và tại sao. -->

## Loại thay đổi

- [ ] `feat` — Feature mới
- [ ] `fix` — Bug fix
- [ ] `bench` — Benchmark/experiment mới
- [ ] `docs` — Cập nhật tài liệu
- [ ] `refactor` — Refactor code
- [ ] `test` — Thêm/sửa tests
- [ ] `chore` — Deps, config

## Module bị ảnh hưởng

- [ ] `src/common` ⚠️ cần P1 review kỹ nếu thay đổi types/schema
- [ ] `src/ingestion`
- [ ] `src/indexing`
- [ ] `src/retrieval`
- [ ] `src/agent`
- [ ] `src/eval`
- [ ] `src/ui`
- [ ] `configs/`
- [ ] `docs/`

## Checklist schema & API

- [ ] Output đúng schema trong `docs/system/metadata_schema.md`
- [ ] Response format khớp `docs/api/retrieval_api_contract.md`
- [ ] Không break import của module khác
- [ ] Config thay đổi được phản ánh trong YAML

## Checklist chất lượng code

- [ ] Đã chạy `black src/` (không có lỗi)
- [ ] Đã chạy `ruff src/` (không có lỗi)
- [ ] Đã thêm type hints cho function public
- [ ] Đã thêm docstring

## Benchmark / Evidence

<!-- Dán bảng benchmark nếu có, hoặc link tới reports/ -->

## Cách test / reproduce

```bash
# Lệnh để reviewer test PR này
```
