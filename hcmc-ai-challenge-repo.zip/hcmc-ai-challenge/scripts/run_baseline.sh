#!/usr/bin/env bash
# Run end-to-end baseline pipeline
# Usage: bash scripts/run_baseline.sh [--video-dir PATH] [--subset N]

set -e

VIDEO_DIR="data/raw"
SUBSET=""

while [[ "$#" -gt 0 ]]; do
  case $1 in
    --video-dir) VIDEO_DIR="$2"; shift ;;
    --subset) SUBSET="--subset $2"; shift ;;
  esac
  shift
done

echo "=== Running Baseline Pipeline ==="
echo "Video dir: $VIDEO_DIR"

# TODO (Phase 1): Uncomment when scripts are ready
# echo "[1/4] Extracting keyframes..."
# python src/ingestion/extract_keyframes.py --video-dir $VIDEO_DIR $SUBSET --config configs/indexing.yaml

# echo "[2/4] Building CLIP index..."
# python src/indexing/build_clip_index.py --config configs/indexing.yaml

# echo "[3/4] Running evaluation on sample queries..."
# python src/eval/benchmark.py --queries data/queries/sample_queries.jsonl --config configs/eval.yaml

# echo "[4/4] Done! Check reports/phase1/ for results."

echo "⚠️  TODO: Fill in after Phase 1 modules are ready."
