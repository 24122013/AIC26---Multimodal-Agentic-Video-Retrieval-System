#!/usr/bin/env bash
# Setup script — chạy một lần khi clone repo

set -e

echo "=== HCMC AI Challenge — Setup ==="

# Create virtual environment
if [ ! -d ".venv" ]; then
  echo "[1/4] Creating virtual environment..."
  python3 -m venv .venv
fi

# Activate
source .venv/bin/activate
echo "[2/4] Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create necessary data directories
echo "[3/4] Creating data directories..."
mkdir -p data/raw data/keyframes data/segments data/metadata data/embeddings data/queries
mkdir -p logs

# Check GPU
echo "[4/4] Checking GPU..."
python3 -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')" || echo "PyTorch not yet installed"

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Add your video data to data/raw/"
echo "  2. Edit configs/ to match your setup"
echo "  3. Run: bash scripts/run_baseline.sh"
