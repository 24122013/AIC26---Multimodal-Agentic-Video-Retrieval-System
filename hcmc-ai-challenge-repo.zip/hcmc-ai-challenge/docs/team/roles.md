# Team Roles & Responsibilities

## Nhóm 5 người — HCMC AI Challenge 2026

---

## P1 — Team Lead / System Integration / Evaluation

### Trách nhiệm chính
- Quản lý repo, kiến trúc tổng thể, API contract
- Review tất cả PR ảnh hưởng đến shared schema/types
- Viết và duy trì evaluation pipeline
- Điều phối ablation experiments
- Tổng hợp kết quả để viết paper

### Owns (chịu trách nhiệm output)
| File/Module | Mô tả |
|-------------|-------|
| `docs/system/system_design_v0.md` | Kiến trúc tổng thể |
| `src/eval/metrics.py` | Recall@K, MRR, latency |
| `src/eval/benchmark.py` | Evaluator chính |
| `src/eval/ablation.py` | Multi-config ablation runner |
| `scripts/run_baseline.sh` | Pipeline end-to-end |
| `scripts/run_eval.sh` | Chạy evaluation |
| `scripts/run_ablation.sh` | Ablation runner |
| `CONTRIBUTING.md` | Coding convention |

### Quyền đặc biệt
- Approve/reject mọi PR vào `develop` và `main`
- Quyết định thay đổi metadata schema
- Quyết định thay đổi API contract

---

## P2 — Indexing & Embedding Engineer

### Trách nhiệm chính
- Extract keyframe và segment từ video
- Benchmark và chọn model embedding tốt nhất
- Build và quản lý vector database

### Owns
| File/Module | Mô tả |
|-------------|-------|
| `src/ingestion/extract_keyframes.py` | Keyframe extraction |
| `src/ingestion/extract_segments.py` | Segment/shot extraction |
| `src/indexing/build_clip_index.py` | CLIP/SigLIP/OpenCLIP encoder |
| `src/indexing/vector_db.py` | FAISS/Qdrant interface |
| `data/metadata/embeddings_index.jsonl` | Embedding index |
| `reports/phase2/model_embedding_benchmark.md` | Embedding comparison |
| `docs/system/keyframe_extraction_plan.md` | Extraction plan |
| `docs/system/embedding_baseline_choice.md` | Model choice rationale |

### Interface với team
- Output keyframe phải tuân theo schema trong `metadata_schema.md`
- `vector_db.py` phải expose interface mà P4 dùng được
- Coordinate với P3 về path keyframe

---

## P3 — Metadata & Multimodal Extraction Engineer

### Trách nhiệm chính
- Extract caption, OCR, ASR, object detection
- Thiết kế và maintain metadata schema
- Build metadata loader dùng chung

### Owns
| File/Module | Mô tả |
|-------------|-------|
| `src/ingestion/run_caption.py` | Caption generation |
| `src/ingestion/run_ocr.py` | OCR extraction |
| `src/ingestion/run_asr.py` | ASR transcription |
| `src/ingestion/run_object_detection.py` | Object detection |
| `src/common/metadata_store.py` | Metadata loader dùng chung |
| `data/metadata/captions.jsonl` | Caption output |
| `data/metadata/ocr.jsonl` | OCR output |
| `data/metadata/asr.jsonl` | ASR output |
| `data/metadata/objects.jsonl` | Object detection output |
| `docs/system/metadata_schema.md` | Schema chính thức |
| `docs/system/multimodal_tools_v0.md` | Tool selection |

### Interface với team
- `metadata_store.py` phải load được tất cả `.jsonl` files
- Schema phải khớp với `metadata_schema.md`
- P4 phụ thuộc vào `metadata_store.py` cho text search

---

## P4 — Retrieval / Re-ranking / Temporal Search Engineer

### Trách nhiệm chính
- Xây dựng visual, text và hybrid search
- Implement re-ranking (cross-encoder, VLM)
- Implement temporal search cho multi-event queries

### Owns
| File/Module | Mô tả |
|-------------|-------|
| `src/retrieval/search_visual.py` | Text → CLIP → vector search |
| `src/retrieval/search_text.py` | BM25 text search |
| `src/retrieval/hybrid_search.py` | Combined retrieval |
| `src/retrieval/rerank.py` | Cross-encoder / VLM rerank |
| `src/retrieval/temporal_search.py` | Multi-event temporal |
| `src/retrieval/types.py` | SearchResult, SearchQuery |
| `src/indexing/build_text_index.py` | BM25 index builder |
| `configs/retrieval.yaml` | Hybrid weights config |
| `docs/api/retrieval_api_contract.md` | API spec |
| `reports/phase1/baseline_retrieval_w2.md` | Baseline results |

### Interface với team
- Phải implement đúng function signatures trong `retrieval_api_contract.md`
- `SearchResult` type là contract với P5 (UI) và P1 (Eval)
- Sử dụng `metadata_store.py` của P3 để load text data

---

## P5 — Agent / UI / Competition Workflow Engineer

### Trách nhiệm chính
- Xây dựng agentic query understanding & tool calling
- Build Competition UI với đầy đủ features thi đấu
- Interaction logging cho paper & debug
- Tổ chức mock contest workflow

### Owns
| File/Module | Mô tả |
|-------------|-------|
| `src/agent/planner.py` | Query decomposition & planning |
| `src/agent/tools.py` | Tool definitions (gọi P4 modules) |
| `src/agent/prompts.py` | LLM prompt templates |
| `src/agent/query_expansion.py` | Vi/En query expansion |
| `src/ui/app.py` | Main UI entry point |
| `src/ui/components/` | Reusable UI components |
| `logs/search_log.jsonl` | Interaction logs |
| `docs/system/ui_wireframe_v0.md` | UI wireframe |
| `docs/system/interaction_log_schema.md` | Log schema |

### Interface với team
- Agent tools phải gọi qua interface của P4 (không bypass)
- UI phải consume `SearchResult` type từ P4
- Log format phải khớp `interaction_log_schema.md`

---

## RACI Matrix

| Hạng mục | P1 Lead | P2 Index | P3 Meta | P4 Retrieval | P5 Agent/UI |
|----------|---------|----------|---------|--------------|-------------|
| Repo/architecture | **A/R** | C | C | C | C |
| Metadata schema | **A** | C | **R** | C | C |
| Keyframe extraction | I | **A/R** | C | I | I |
| Embedding benchmark | C | **A/R** | I | C | I |
| Caption/OCR/ASR | C | I | **A/R** | C | C |
| Vector DB | C | **A/R** | C | C | I |
| Visual retrieval | C | C | I | **A/R** | C |
| Hybrid retrieval | C | C | C | **A/R** | C |
| Re-ranking | C | I | C | **A/R** | C |
| Temporal search | C | C | C | **A/R** | C |
| Agent planner | C | I | C | C | **A/R** |
| Query expansion | C | I | C | C | **A/R** |
| UI baseline | C | I | C | C | **A/R** |
| Competition UI | C | I | C | C | **A/R** |
| Evaluation protocol | **A/R** | C | C | C | C |
| Mock contest | **A/R** | I | I | C | **R** |
| Paper writing | **A/R** | R (section) | R (section) | R (section) | R (section) |
