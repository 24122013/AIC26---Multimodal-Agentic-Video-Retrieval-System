# Weekly Report Template

**Cách dùng:** Copy file này → đổi tên thành `week-XX-PX.md` → điền vào → commit vào `reports/weekly/`

---

# Weekly Report — Week [X] — [Tên / Role]

> **Ngày:** [DD/MM/YYYY]  
> **Role:** [P1/P2/P3/P4/P5 — Tên vai trò]  
> **Phase hiện tại:** [Phase X]

---

## ✅ Done

<!-- Liệt kê những việc đã hoàn thành trong tuần. Mỗi item phải có link commit hoặc file cụ thể. -->

- [ ] [Mô tả task 1] → [link commit/file]
- [ ] [Mô tả task 2] → [link commit/file]

---

## 📊 Demo / Evidence

<!-- Bắt buộc nếu có module mới hoặc cải tiến. Không có evidence = chưa done. -->

**Script chạy được:**
```
# Lệnh để reproduce
python src/xxx/yyy.py --config configs/xxx.yaml
```

**Kết quả / Benchmark:**

| Metric | Giá trị | Ghi chú |
|--------|---------|---------|
| Recall@10 | — | — |
| Recall@50 | — | — |
| Latency (ms) | — | — |

**Log / Output mẫu:**
```
# Paste log hoặc output ngắn ở đây
```

---

## 🚫 Problems / Blockers

<!-- Những vấn đề gặp phải và cần hỗ trợ. Nếu không có blocker: "Không có." -->

- **[Vấn đề 1]:** [Mô tả] → Cần hỗ trợ từ: [Người]
- **[Vấn đề 2]:** [Mô tả] → Đang tự giải quyết

---

## 📅 Next Week

<!-- Kế hoạch tuần sau. Phải cụ thể, có output rõ ràng. -->

- [ ] [Task 1] → Output: [file/script/benchmark]
- [ ] [Task 2] → Output: [file/script/benchmark]

---

## 📝 Notes

<!-- Bất kỳ điều gì muốn share với team: phát hiện kỹ thuật, risk mới, đề xuất thay đổi, ... -->
