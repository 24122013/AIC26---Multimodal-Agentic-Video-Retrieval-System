# Definition of Done

Mỗi loại task có tiêu chí "done" riêng. Task chỉ được đóng khi **tất cả** checkbox được check.

---

## Script Ingestion (P2, P3)

- [ ] Có CLI chạy được: `python run_xxx.py --help` ra đúng usage
- [ ] Có config input/output qua YAML hoặc CLI args
- [ ] Output đúng schema trong `docs/system/metadata_schema.md`
- [ ] Có sample output (1–5 records) trong `data/metadata/` kèm theo
- [ ] Có log runtime (tốc độ xử lý, số records, errors)
- [ ] Có hướng dẫn chạy trong module `README.md`
- [ ] Có đo thời gian xử lý trên subset

---

## Retrieval Module (P4)

- [ ] Có function/API rõ ràng với type hints và docstring
- [ ] Trả về đúng `SearchResult` format (xem `retrieval_api_contract.md`)
- [ ] Có test với ≥ 5 query mẫu từ `data/queries/sample_queries.jsonl`
- [ ] Có đo latency (mean/p50/p95)
- [ ] Có benchmark Recall@10 và Recall@50 trên subset

---

## UI Feature (P5)

- [ ] Dùng được trong mock contest không cần chỉnh code giữa chừng
- [ ] Có log interaction theo `interaction_log_schema.md`
- [ ] Không làm vỡ flow search hiện tại (regression test)
- [ ] Đã test thủ công với ≥ 10 query thực tế
- [ ] Không có hardcoded path hay config

---

## Agent Tool (P5)

- [ ] Tool gọi qua interface chính thức của P4 (không trực tiếp vào DB)
- [ ] Có output format rõ ràng
- [ ] Có test với ≥ 3 query tiếng Việt và 3 query tiếng Anh
- [ ] Có log tool calls để debug

---

## Experiment / Ablation (P1, tất cả)

- [ ] Có config YAML rõ ràng, không hardcode trong script
- [ ] Có script để người khác chạy lại (`scripts/run_ablation.sh`)
- [ ] Có bảng kết quả số liệu (Recall@K, latency)
- [ ] Có nhận xét ngắn về kết quả
- [ ] Có lưu log/artifact tại `reports/phaseX/`

---

## Document / Spec

- [ ] Đúng format Markdown
- [ ] Có section "Last updated" và "Người phụ trách"
- [ ] Có ví dụ cụ thể (JSON sample, code snippet)
- [ ] Không có thông tin mâu thuẫn với docs khác

---

## Pull Request

- [ ] Đã điền đầy đủ PR template
- [ ] Đã chạy `black` và `ruff` (không có lỗi)
- [ ] Đã tự review diff trước khi gửi
- [ ] Đã tag P1 để review
- [ ] Không commit data thật hoặc file lớn
