# Phase 0 — Chuẩn bị hệ thống và chốt spec

> **Thời gian:** 2–3 ngày  
> **Mục tiêu:** Chốt hướng làm, repo, schema, subset dataset, metric nội bộ.

---

## Phân công chi tiết

| Người | Việc cần làm | Output | Deadline |
|-------|-------------|--------|----------|
| **P1** | Tạo repo, branch, README, coding convention, task board | `README.md`, `CONTRIBUTING.md` | Ngày 1 |
| **P1** | Thiết kế kiến trúc tổng thể v0 | `docs/system/system_design_v0.md` | Ngày 2 |
| **P2** | Khảo sát keyframe/segment extraction (OpenCV/ffmpeg) | `docs/system/keyframe_extraction_plan.md` | Ngày 2 |
| **P2** | Đề xuất model embedding baseline | `docs/system/embedding_baseline_choice.md` | Ngày 2 |
| **P3** | Thiết kế metadata schema toàn hệ thống | `docs/system/metadata_schema.md` | Ngày 2 |
| **P3** | Chọn tool OCR/caption/ASR/object baseline | `docs/system/multimodal_tools_v0.md` | Ngày 3 |
| **P4** | Thiết kế API search ban đầu | `docs/api/retrieval_api_contract.md` | Ngày 2 |
| **P4** | Chốt metric: Recall@K, MRR, latency, solve time | `src/eval/metrics.py` draft + `docs/eval_protocol.md` | Ngày 3 |
| **P5** | Wireframe UI baseline | `docs/system/ui_wireframe_v0.md` | Ngày 2 |
| **P5** | Thiết kế interaction log schema | `docs/system/interaction_log_schema.md` | Ngày 3 |

---

## Checklist hoàn thành phase

- [ ] Repo đã khởi tạo và có folder structure chuẩn
- [ ] Repo chạy được lệnh setup cơ bản (`bash scripts/setup.sh`)
- [ ] Có `docs/system/metadata_schema.md` được toàn team đồng ý
- [ ] Có `docs/system/system_design_v0.md`
- [ ] Có `docs/api/retrieval_api_contract.md` draft
- [ ] Có ít nhất 20 query mẫu trong `data/queries/sample_queries.jsonl`
- [ ] Có subset video nhỏ (100–500 video) để test
- [ ] Mỗi người có task cụ thể trong Phase 1
- [ ] Task board đã setup với backlog rõ ràng
