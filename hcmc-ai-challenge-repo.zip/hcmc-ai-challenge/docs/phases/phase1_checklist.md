# Phase 1 — Baseline End-to-End

> **Thời gian:** Tuần 1–2  
> **Mục tiêu:** Có hệ thống chạy được từ video đến search UI.

```
Video → Keyframe → Embedding → Vector index → Text query → Top-k keyframes → UI preview
```

Chưa cần tối ưu. Ưu tiên có pipeline chạy từ đầu đến cuối.

---

## Phân công chi tiết

| Người | Việc cần làm | Output | Deadline |
|-------|-------------|--------|----------|
| **P1** | Tạo pipeline command chung: ingest → index → search → eval | `scripts/run_baseline.sh` | Tuần 1 |
| **P1** | Viết evaluator baseline | `src/eval/benchmark.py`, `src/eval/metrics.py` | Tuần 2 |
| **P1** | Review PR, đảm bảo mọi module khớp schema | Merge checklist + API review | Liên tục |
| **P2** | Script extract keyframe theo interval config | `src/ingestion/extract_keyframes.py` | Tuần 1 |
| **P2** | Encode keyframe bằng model baseline | `src/indexing/build_clip_index.py` | Tuần 1 |
| **P2** | Lưu embedding vào FAISS/Qdrant local | `src/indexing/vector_db.py` | Tuần 2 |
| **P3** | Tạo metadata JSON/Parquet cho keyframe | `data/metadata/keyframes.jsonl` | Tuần 1 |
| **P3** | Viết metadata loader dùng chung | `src/common/metadata_store.py` | Tuần 2 |
| **P4** | Viết search function: text → embedding → vector search | `src/retrieval/search_visual.py` | Tuần 1 |
| **P4** | Chuẩn hóa response format | `src/retrieval/types.py` | Tuần 2 |
| **P4** | Test retrieval với 20–50 query mẫu | `reports/phase1/baseline_retrieval_w2.md` | Tuần 2 |
| **P5** | UI baseline: search box + result grid | `src/ui/app.py` (Streamlit) | Tuần 1 |
| **P5** | Click result mở video tại timestamp | UI demo | Tuần 2 |
| **P5** | Ghi log query/result/latency | `logs/search_log.jsonl` | Tuần 2 |

---

## Demo bắt buộc cuối Phase 1

```
Query: "a man cooking in a kitchen"
→ Hệ thống trả về top-20 keyframes
→ Click vào một result
→ Mở đúng video/timestamp
→ Log lại query và latency
```

---

## Tiêu chí đạt phase

- [ ] Có thể chạy baseline bằng một command: `bash scripts/run_baseline.sh`
- [ ] Search latency < 5 giây trên subset nhỏ
- [ ] UI hiển thị được top-k results
- [ ] Có benchmark đầu tiên (Recall@10, latency) tại `reports/phase1/`
- [ ] Có danh sách lỗi thực tế sau khi test 20 query
