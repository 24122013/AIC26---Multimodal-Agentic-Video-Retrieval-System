# Metadata Schema — HCMC AI Challenge

> **Người phụ trách:** P3 (Metadata & Multimodal)  
> **Người review:** P1 (Tech Lead)  
> **Last updated:** Phase 0

Schema này là **contract chung** cho toàn team. Mọi module phải tuân theo format này.  
Nếu muốn thay đổi schema, cần tạo PR và P1 phải approve.

---

## 1. Keyframe metadata

File: `data/metadata/keyframes.jsonl` (1 object/line)

```json
{
  "video_id": "L01_V001",
  "segment_id": "L01_V001_S003",
  "keyframe_id": "L01_V001_S003_F042",
  "keyframe_path": "data/keyframes/L01/V001/S003/frame_042.jpg",
  "timestamp": 12.5,
  "start_time": 10.0,
  "end_time": 15.0,
  "duration": 5.0,
  "fps": 25.0,
  "frame_index": 42,
  "width": 1920,
  "height": 1080
}
```

### Quy tắc ID

| Field | Format | Ví dụ |
|-------|--------|-------|
| `video_id` | `{batch}_{video_num}` | `L01_V001` |
| `segment_id` | `{video_id}_S{seg_num:03d}` | `L01_V001_S003` |
| `keyframe_id` | `{segment_id}_F{frame_num:04d}` | `L01_V001_S003_F0042` |

---

## 2. Caption metadata

File: `data/metadata/captions.jsonl`

```json
{
  "keyframe_id": "L01_V001_S003_F0042",
  "video_id": "L01_V001",
  "timestamp": 12.5,
  "caption": "A man in a red shirt is standing near a bus stop on a rainy street.",
  "caption_model": "blip2-opt-2.7b",
  "caption_lang": "en",
  "confidence": 0.92,
  "generated_at": "2026-01-15T10:30:00"
}
```

---

## 3. OCR metadata

File: `data/metadata/ocr.jsonl`

```json
{
  "keyframe_id": "L01_V001_S003_F0042",
  "video_id": "L01_V001",
  "timestamp": 12.5,
  "ocr_text": "BUS STOP\n23B NGUYEN HUE",
  "ocr_lines": [
    {"text": "BUS STOP", "bbox": [120, 45, 280, 75], "confidence": 0.98},
    {"text": "23B NGUYEN HUE", "bbox": [110, 80, 310, 105], "confidence": 0.87}
  ],
  "ocr_model": "paddleocr-v4",
  "language_detected": "en",
  "generated_at": "2026-01-15T10:35:00"
}
```

---

## 4. ASR metadata

File: `data/metadata/asr.jsonl`

```json
{
  "video_id": "L01_V001",
  "segment_id": "L01_V001_S003",
  "start_time": 10.0,
  "end_time": 15.0,
  "transcript": "Chờ một chút, tôi sẽ gặp anh ở đó.",
  "transcript_en": "Wait a moment, I will meet you there.",
  "language": "vi",
  "asr_model": "faster-whisper-large-v3",
  "word_timestamps": [
    {"word": "Chờ", "start": 10.2, "end": 10.5},
    {"word": "một", "start": 10.5, "end": 10.7}
  ],
  "generated_at": "2026-01-15T11:00:00"
}
```

---

## 5. Object detection metadata

File: `data/metadata/objects.jsonl`

```json
{
  "keyframe_id": "L01_V001_S003_F0042",
  "video_id": "L01_V001",
  "timestamp": 12.5,
  "objects": [
    {
      "label": "person",
      "confidence": 0.95,
      "bbox": [200, 100, 450, 800],
      "attributes": ["red shirt", "male"]
    },
    {
      "label": "bus",
      "confidence": 0.88,
      "bbox": [800, 200, 1800, 900]
    },
    {
      "label": "umbrella",
      "confidence": 0.76,
      "bbox": [180, 50, 500, 200]
    }
  ],
  "detection_model": "yolo-world-v2",
  "generated_at": "2026-01-15T11:30:00"
}
```

---

## 6. Embedding metadata

File: `data/metadata/embeddings_index.jsonl` (index file, không lưu vector thực ở đây)

```json
{
  "keyframe_id": "L01_V001_S003_F0042",
  "video_id": "L01_V001",
  "timestamp": 12.5,
  "embedding_model": "openclip-ViT-L-14",
  "embedding_dim": 768,
  "embedding_index_id": 42,
  "index_file": "data/embeddings/openclip_vitl14.faiss"
}
```

---

## 7. SearchResult type (API contract)

Dùng khi trả kết quả từ retrieval module (xem thêm `docs/api/retrieval_api_contract.md`):

```json
{
  "keyframe_id": "L01_V001_S003_F0042",
  "video_id": "L01_V001",
  "timestamp": 12.5,
  "keyframe_path": "data/keyframes/L01/V001/S003/frame_042.jpg",
  "score": 0.847,
  "scores_breakdown": {
    "visual": 0.82,
    "caption": 0.91,
    "ocr": 0.0,
    "object": 0.75,
    "temporal": 0.60
  },
  "caption": "A man in a red shirt is standing near a bus stop.",
  "ocr_text": "BUS STOP",
  "objects": ["person", "bus", "umbrella"],
  "neighbor_frames": {
    "prev_5": ["...frame_037.jpg", "...frame_038.jpg", "...frame_039.jpg", "...frame_040.jpg", "...frame_041.jpg"],
    "next_5": ["...frame_043.jpg", "...frame_044.jpg", "...frame_045.jpg", "...frame_046.jpg", "...frame_047.jpg"]
  },
  "search_method": "hybrid_clip_caption_ocr"
}
```

---

## 8. Interaction log schema

File: `logs/search_log.jsonl`

```json
{
  "session_id": "session_20260115_143022",
  "query_id": "q_001",
  "timestamp": "2026-01-15T14:30:22",
  "query": "a man in a red shirt near a bus",
  "query_lang": "en",
  "search_method": "hybrid",
  "top_k": 50,
  "latency_ms": 1420,
  "results_returned": 50,
  "clicked_results": ["L01_V001_S003_F0042"],
  "submitted_result": "L01_V001_S003_F0042",
  "success": true,
  "solve_time_ms": 45000,
  "agent_used": false,
  "query_expanded": false
}
```

---

## Changelog schema

| Version | Ngày | Thay đổi | Người thay đổi |
|---------|------|----------|----------------|
| v0.1 | Phase 0 | Draft ban đầu | P3 |
| — | — | — | — |
