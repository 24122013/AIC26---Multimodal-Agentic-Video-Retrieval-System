# Retrieval API Contract

> **Người phụ trách:** P4 (Retrieval)  
> **Người review:** P1 (Tech Lead)  
> **Last updated:** Phase 0

Đây là **contract chính thức** giữa Retrieval module và các module khác (Agent, UI, Eval).  
Mọi thay đổi interface cần qua PR + review của P1.

---

## 1. Core types

```python
# src/retrieval/types.py

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SearchQuery:
    """Query đầu vào cho retrieval engine."""
    text: str                          # Query text (tiếng Việt hoặc tiếng Anh)
    top_k: int = 50                    # Số kết quả muốn lấy
    method: str = "hybrid"             # "visual" | "text" | "hybrid" | "temporal"
    filters: dict = field(default_factory=dict)  # {"video_id": "...", "time_range": [0, 300]}
    language: str = "auto"             # "vi" | "en" | "auto"


@dataclass
class ScoreBreakdown:
    """Chi tiết điểm số theo từng modality."""
    visual: float = 0.0
    caption: float = 0.0
    ocr: float = 0.0
    object: float = 0.0
    temporal: float = 0.0


@dataclass
class SearchResult:
    """Một kết quả truy xuất."""
    keyframe_id: str
    video_id: str
    timestamp: float
    keyframe_path: str
    score: float                       # Final combined score
    scores_breakdown: ScoreBreakdown = field(default_factory=ScoreBreakdown)
    caption: Optional[str] = None
    ocr_text: Optional[str] = None
    objects: list[str] = field(default_factory=list)
    neighbor_frames: Optional[dict] = None   # {"prev_5": [...], "next_5": [...]}
    search_method: str = "hybrid"


@dataclass
class SearchResponse:
    """Response đầy đủ từ retrieval engine."""
    query: SearchQuery
    results: list[SearchResult]
    total_found: int
    latency_ms: float
    method_used: str
```

---

## 2. Function signatures

### Visual search

```python
def search_visual(
    query: str,
    top_k: int = 50,
    filters: dict | None = None,
) -> list[SearchResult]:
    """Tìm keyframes bằng text query thông qua CLIP/SigLIP embedding.

    Args:
        query: Text mô tả cảnh cần tìm.
        top_k: Số lượng kết quả.
        filters: Optional filter dict.

    Returns:
        Danh sách SearchResult sắp xếp theo score giảm dần.
    """
```

### Text search (BM25)

```python
def search_text(
    query: str,
    fields: list[str] = ["caption", "ocr", "asr"],
    top_k: int = 50,
    filters: dict | None = None,
) -> list[SearchResult]:
    """Tìm bằng BM25 trên caption/OCR/ASR text."""
```

### Hybrid search

```python
def hybrid_search(
    query: str,
    top_k: int = 50,
    weights: dict | None = None,
    filters: dict | None = None,
) -> SearchResponse:
    """Kết hợp visual + text search với weighted scoring.

    Default weights (từ configs/retrieval.yaml):
        visual:   0.45
        caption:  0.25
        ocr:      0.15
        object:   0.10
        temporal: 0.05
    """
```

### Temporal search

```python
def temporal_search(
    events: list[str],
    constraints: dict,
    top_k: int = 20,
) -> SearchResponse:
    """Tìm theo chuỗi sự kiện có ràng buộc thời gian.

    Args:
        events: Danh sách sub-queries theo thứ tự.
        constraints: Ví dụ {"order": "sequential", "max_gap_sec": 30}.
        top_k: Số kết quả mỗi event.

    Example:
        events = [
            "man enters shop",
            "man talks to cashier"
        ]
        constraints = {"order": "sequential", "max_gap_sec": 60}
    """
```

### Rerank

```python
def rerank(
    candidates: list[SearchResult],
    query: str,
    method: str = "cross_encoder",
    top_k: int = 20,
) -> list[SearchResult]:
    """Rerank candidates dùng cross-encoder hoặc VLM.

    Args:
        method: "cross_encoder" | "vlm" | "llm_caption"
    """
```

---

## 3. Hybrid scoring formula

```python
# configs/retrieval.yaml — default weights
score = (
    0.45 * visual_score
  + 0.25 * caption_score
  + 0.15 * ocr_score
  + 0.10 * object_score
  + 0.05 * temporal_score
)
```

Weights này có thể override qua `configs/retrieval.yaml` và không được hardcode trong code.

---

## 4. Error handling

```python
class IndexNotReadyError(Exception):
    """Raised khi vector index chưa được build."""

class ModelNotLoadedError(Exception):
    """Raised khi model chưa được load."""

class SearchTimeoutError(Exception):
    """Raised khi search vượt quá timeout (default 10s)."""
```

---

## 5. Ví dụ sử dụng

```python
from src.retrieval.hybrid_search import hybrid_search
from src.retrieval.rerank import rerank

# Bước 1: Hybrid search top-50
response = hybrid_search(
    query="a man in red shirt near bus stop",
    top_k=50,
)

# Bước 2: Rerank top-20 từ kết quả
final_results = rerank(
    candidates=response.results[:50],
    query="a man in red shirt near bus stop",
    method="cross_encoder",
    top_k=20,
)

# Bước 3: Dùng trong UI
for r in final_results[:10]:
    print(f"{r.video_id} @ {r.timestamp:.1f}s — score: {r.score:.3f}")
```

---

## Changelog

| Version | Ngày | Thay đổi | Người thay đổi |
|---------|------|----------|----------------|
| v0.1 | Phase 0 | Draft ban đầu | P4 |
| — | — | — | — |
