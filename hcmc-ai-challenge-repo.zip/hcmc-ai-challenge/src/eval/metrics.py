"""Evaluation metrics: Recall@K, MRR, latency.

Owner: P4 (initial draft), P1 (final)
Status: TODO — implement in Phase 0/1
"""
from __future__ import annotations

from typing import Any


def recall_at_k(
    ground_truth: list[str],
    retrieved: list[str],
    k: int,
) -> float:
    """Compute Recall@K.

    Args:
        ground_truth: List of correct keyframe/video IDs.
        retrieved: Ordered list of retrieved IDs.
        k: Cutoff rank.

    Returns:
        Recall@K score between 0 and 1.
    """
    # TODO: implement
    raise NotImplementedError


def mean_reciprocal_rank(
    ground_truth: list[str],
    retrieved: list[str],
) -> float:
    """Compute Mean Reciprocal Rank (MRR).

    Args:
        ground_truth: List of correct IDs.
        retrieved: Ordered list of retrieved IDs.

    Returns:
        MRR score.
    """
    # TODO: implement
    raise NotImplementedError
