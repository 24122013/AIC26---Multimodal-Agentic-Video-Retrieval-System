# Module: ingestion

> **Người phụ trách:** [Xem docs/team/roles.md]  
> ⚠️ **TODO:** Cập nhật sau khi module được implement.

## Mô tả

<!-- Mô tả ngắn module này làm gì -->

## Files chính

| File | Mô tả | Status |
|------|-------|--------|
| — | — | 🔲 TODO |

## Cách chạy

```bash
# TODO: Thêm sau khi implement
```

## Input / Output

- **Input:** TODO
- **Output:** Xem `docs/system/metadata_schema.md`

## Dependencies

- Phụ thuộc vào: [module/file khác]
- Được dùng bởi: [module/file khác]
