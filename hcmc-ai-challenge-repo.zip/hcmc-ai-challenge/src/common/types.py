"""Shared type definitions used across all modules.

Owner: P4 (types) + P1 (review)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SearchQuery:
    """Query input for the retrieval engine."""
    text: str
    top_k: int = 50
    method: str = "hybrid"  # "visual" | "text" | "hybrid" | "temporal"
    filters: dict = field(default_factory=dict)
    language: str = "auto"  # "vi" | "en" | "auto"


@dataclass
class ScoreBreakdown:
    """Per-modality score breakdown."""
    visual: float = 0.0
    caption: float = 0.0
    ocr: float = 0.0
    object: float = 0.0
    temporal: float = 0.0


@dataclass
class SearchResult:
    """A single retrieval result."""
    keyframe_id: str
    video_id: str
    timestamp: float
    keyframe_path: str
    score: float
    scores_breakdown: ScoreBreakdown = field(default_factory=ScoreBreakdown)
    caption: Optional[str] = None
    ocr_text: Optional[str] = None
    objects: list[str] = field(default_factory=list)
    neighbor_frames: Optional[dict] = None
    search_method: str = "hybrid"


@dataclass
class SearchResponse:
    """Full response from the retrieval engine."""
    query: SearchQuery
    results: list[SearchResult]
    total_found: int
    latency_ms: float
    method_used: str
