"""Config loader for YAML configuration files.

Owner: P1
"""
from __future__ import annotations

from pathlib import Path
import yaml


def load_config(path: str | Path) -> dict:
    """Load a YAML config file.

    Args:
        path: Path to the YAML file.

    Returns:
        Parsed config dict.
    """
    with open(path) as f:
        return yaml.safe_load(f)
